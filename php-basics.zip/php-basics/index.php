<?php
require '_init.php'; // import all needed files dont forget when create  a new one

Router::make()
    // 'route name' , [controller::function , 'function name as a string']
    ->get('', [TaskController::index(), 'index']) // get request
    ->post('task/create', [TaskController::create(), 'create']) // post request
    ->resolve(Request::uri(), Request::method());
