<?php 

require 'resources/about.view.php';